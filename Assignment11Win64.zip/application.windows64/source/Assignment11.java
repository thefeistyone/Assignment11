import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.JOptionPane; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Assignment11 extends PApplet {


Question [] questions = new Question[5];
String [] q1Prompts = {"Enter the mass of block A in kg:", "Enter the mass of block B in kg:", "Enter the value of a in mm:", "Enter the value of b in mm:", "Enter the value of uab:", "Enter the value of ua:"};
String [] q2Prompts = {"Enter the value of the torque M in Nm:", "Enter the value of the coefficient of static friction:", "Enter the value of a in mm:", "Enter the value of b in mm:", "Enter the value of c in mm:"};
String [] q3Prompts = {"Enter the value of L in m:", "Enter the value of theta in degrees:"};
String [] q4Prompts = {"Enter the mass of block A in kg:", "Enter the mass of block B in kg:", "Enter the value of a in degrees:", "Enter the value of the coefficient of friction:"};
String [] q5Prompts = {"Enter the mass of the man in kg:", "Enter the coefficient of friction:", "Enter the value of a in m:", "Enter the value of b in m:"};

boolean home = true;
boolean credits = false;
boolean showQuestion = false;
boolean input = true;
boolean output = false;
boolean showSteps = false;
boolean settings = false;

int maxY = 1000;

Button submit = new Button("Submit", 60, 25, 5, 50, 425);
Button solutions = new Button("Show Steps", 100, 25, 5, 50, 425);
Button creditsButton = new Button("Credits", 60, 25, 5, 370, 425);
Button back = new Button("Home", 50, 25, 5, 700, 425);
Button settingsButton =  new Button("Settings", 75, 25, 5, 675, 425);
Settings mySettings = new Settings();


public void setup() {
  
  background(255);
  surface.setLocation(0, 0);
  questions[0] = new Question(6, 1, q1Prompts, 85, 100, "question1.JPG", "solution1.JPG");
  questions[1] = new Question(5, 2, q2Prompts, 295, 100, "question2.JPG", "solution2.jpg");
  questions[2] = new Question(2, 3, q3Prompts, 505, 100, "question3.JPG", "solution3.jpg");
  questions[3] = new Question(4, 4, q4Prompts, 180, 260, "question4.JPG", "solution4.jpg");
  questions[4] = new Question(4, 5, q5Prompts, 410, 260, "question5.JPG", "solution5.jpg");
}

public void draw() {
  //resetting canvas
  background(255);

  //if home is activated draw home screen
  if (home) {
    home();
  } 

  //if credits are activated, draw the credits screen
  else if (credits) {
    credits();
  }

  //if a question is activated show that question
  else if (showQuestion) {
    questions();
  } else if (settings) {
    mySettings.update();
  }
}


public void mousePressed() {

  //if on home page check for relevant button clicks; main question buttons
  if (home) {

    for (int i = 0; i < questions.length; i++) {

      //if the button is clicked, deactivate home page, activate question page
      if (questions[i].mainButton.hover() && home) {
        questions[i].active = true;
        input = true;
        home = false;
        showQuestion = true;
      }
    }

    //if settings is pressed while on home page
    if (settingsButton.hover()) {
      settings = true;
      home = false;
    }
  }

  //if on the credits page check for back button click
  else if (credits) {
    if (back.hover()) {
      credits = false;
      home = true;
    }
  }

  //if on the settings page pass event on to mySettings object
  else if (settings) {
    mySettings.mousePressed();
  }

  //if showing a question pass the event on to all question objects
  else {
    for (int i = 0; i < questions.length; i++) {
      questions[i].mouseClicked();
    }
  }
}

public void keyPressed() {

  //passing key press event onto all questions
  for ( int i = 0; i < questions.length; i++ ) {
    questions[i].keyPressed();
  }
}

public void mouseDragged() {
  if (settings) {
    mySettings.mouseDragged();
  }
}

public void solveQuestions() {

  //calling the solve function in the active question
  for (int i = 0; i < questions.length; i++) {
    if (questions[i].active) {
      questions[i].solve();
    }
  }
}

public void home() {

  //showing welcome message
  fill(0);
  textSize(20);
  textAlign(CENTER, TOP);
  text("Welcome to Feisty's 202 Helper!", 400, 10);
  textSize(16);
  text("Select a question below and report any bugs to @thefeistyone.", 400, 40);

  //showing mainbuttons
  for (int i = 0; i < questions.length; i++) {
    questions[i].mainButton.update();
  }

  //showing settings button
  settingsButton.update();
}

public void credits() {

  //showing credits message
  fill(0);
  textSize(30);
  textAlign(LEFT, TOP);
  text("Credits:", 10, 10);
  textSize(16);
  text("Graphical User Interface:\n-thefeistyone \nBack End:\n-thefeistyone \nSolutions:\n-yikes \nApplication Bundling and Distribution:\n-thefeistyone \nSupport\n-thefeistyone \n\nI spend a lot of time developing quality software and solutions \nfor everyone as well as making myself available for support. \nIf you would like to donate to this project please message me and we can set something up. \nBest of luck in ENGG 202! :) -thefeistyone", 10, 50);

  //updating the back button
  back.update();
}

public void questions() {

  //updating all question pages
  for (int i = 0; i < questions.length; i++) {
    questions[i].update();
  }
}

//resets all booleans. No active question, first input textfield active
public void superReset() {
  for (int i = 0; i < questions.length; i++) {
    questions[i].reset();
    input = false;
    output = false;
    showSteps = false;
    showQuestion = false;
    credits = false;
    home = false;
    settings = false;
    hideSolutions();
    mySettings.MaxY.currentVal = 500;
  }
}

//resizing the page and moving home and credits buttons back for exiting the solutions page
public void hideSolutions() {
  surface.setSize(800, 480);
  creditsButton.x = 370;
  creditsButton.y = 425;
  back.x = 700;
  back.y = 425;
}

//resizing the page and moving home and credits buttons for the solutions page
public void showSolutions() {
  int currentQuestion = 0;
  for (int i = 1; i < questions.length; i++) {
    if (questions[i].active) {
      currentQuestion = i;
    }
  }
  int w = (questions[currentQuestion].mySteps.solution.width) + 20;
  surface.setSize(w, maxY);
  creditsButton.x = w - 130;
  creditsButton.y = 50;
  back.x = w - 60;
  back.y = 50;
}

public String question1(double [] input) {
  double wa = input[0] * 9.81f;
  double wb = input[1] * 9.81f;
  double a = input[2] / 1000;
  double b = input[3] / 1000;
  double uab = input[4];
  double ua = input[5];

  double PToppleB = (wb * a ) / ( 2 * b );
  double PMoveB = uab * wb;
  double PMoveBoth = ua * ( wb + wa );
  double [] p = {PToppleB, PMoveB, PMoveBoth};
  double PStatic = min(p);

  String message = "The answers for a mass of A of: " + (float) wa/9.81f + "kg,\n"
    +"a mass of B of: " + (float) wb / 9.81f + "kg,\n"
    +"an a value of: " + (float) a * 1000+ "mm,\n"
    +"a b value of: " + (float) b * 1000 + "mm,\n"
    +"a uab value of: " + (float) uab + "\n"
    +"and a ua value of: " + (float) ua + " are as follows:\n"
    +"\n"
    +"The minimum force that is required to topple block B is: " + myRound(1, PToppleB) + "N.\n"
    +"The minimum force that is required to move block B is: " + myRound(1, PMoveB) + "N.\n"
    +"The minimum force that is required to move both blocks is: " + myRound(1, PMoveBoth) + "N.\n"
    +"The maximum force that can be applie without causing any motion to the blocks is: " + myRound(1, PStatic) + "N.";

  return message;
}

public String question2(double [] input) {
  double m = input[0];
  double u = input[1];
  double a = input[2] / 1000;
  double b = input[3] / 1000;
  double c = input[4] / 1000;

  double ff = m / 0.15f;
  double fn = ff / u;
  double p = ( fn * b + ff * a ) / ( b + c );
  double av = abs(fn - p);
  double fa = sqrt((float) av * (float) av + (float) ff * (float) ff);

  String message = "The answers for a torque, M of: " + m + "Nm,\n"
    +"a coefficient of friction, u of: " + u + ",\n"
    +"an a value of: " + a * 1000 + "mmm, \n"
    +"a b value of: " + b * 1000 + "mm,\n"
    +"and a c value of: " + c * 1000 + "mm, are as follows:\n"
    +"\n"
    +"The minimum force required to prevent rotation of the wheel is: " + myRound(1, p) + "N.\n"
    +"The magnitude of the reaction force at A is: " + myRound(1, fa) + "N.\n";

  return message;
}

public String question3(double [] input) {
  double l = (double) input[0];
  double theta = (double) input[1];

  double u = tan(radians((float)theta));

  String message = "The answers for an L value of: " + l + "m,\n"
    +"and a theta value of: " + theta + "degrees are as follows:\n"
    +"\n"
    +"The minimum coefficient of static friction is: " + myRound(2, u) + ".";

  return message;
}

public String question4(double [] input) {
  double wa = input[0] * 9.81f;
  double wb = input[1] * 9.81f;
  double a = input[2];
  double u = input[3];

  double pa = ( u * wa ) / (cot(a)*cos(a)- u * cos(a));
  double pb = (wb * (sin(a) + u * cos(a))) / ((u * sin(a) - cos(a))*(cot(a)*cos(a) + sin(a)));
  double p = 0;
  char govern = ' ';

  if (abs(pa) < abs(pb)) {
    govern = 'A';
    p = pa;
  } else {
    govern = 'B';
    p = pb;
  }

  double fbc = p * (cot(a)*cos(a)+sin(a));
  double fac = p * cot(a);
  double ffa = fac * cos(a);
  double ffb = 0;
  if (govern == 'B') {
    ffb = (u*fbc)/(sin(a) + (u*cos(a)));
  } else {
    ffb = fbc * cos(a) - wb * sin(a);
  }

  String message = "The answers for a mass of block A of: " + wa / 9.81f + "kg,\n"
    +"a masss of block B of: " + wb / 9.81f + "kg, an angle of: " + a + "degrees\n"
    +"and a coefficient of friction of: " + myRound(2, u) + ", are as follows:\n"
    +"\n"
    +"The block that governs the maximum force is: block " + govern + ".\n"
    +"The maximum force P that can be applied is: " + myRound(1, abs(p)) + "N.\n"
    +"The magnitude of the force in member AC is: " + myRound(1, abs(fac)) + "N.\n"
    +"The magnitude of the force in member BC is: " + myRound(1, abs(fbc)) + "N.\n"
    +"The friction force at body A is: " + myRound(1, abs(ffa)) + "N.\n"
    +"The friction force at body B is: " + myRound(1, abs(ffb)) + "N.\n";


  return message;
}

public String question5(double [] input) {
  double wm = input[0] * 9.81f;
  double u = input[1];
  double a = input[2];
  double b = input[3];

  double theta = 2 * degrees(atan((float) u));
  double fbc = ( wm * b ) / ( a * sin(theta));
  double ah = fbc * sin (( theta / 2 ) );
  double av = ( wm * ( 2 * a * sin( (theta/2)) - b)) / (2 * a * sin((theta/2)));

  String message = "The answers for a mass value of: " + wm / 9.81f + "kg,\n"
    +"a u value of: " + myRound(3, u) + ", \n"
    +"an a value of: " + a + "m, a b value of: " + myRound(3, b) + "m are as follows:\n"
    +"\n"
    +"The maximum angle is: " + myRound(1, theta) + "degrees.\n"
    +"The vertical reaction force at A is: " + myRound(0, av) + "N.\n"
    +"The friction force at A is: " + myRound(0, ah) + "N.";

  return message;
}

public double max(double [] lst) {
  double max = lst[0];
  for (int i = 0; i < lst.length; i++) {
    if (lst[i] > max) {
      max = lst[i];
    }
  }
  return max;
}

public double min(double[] lst) {
  double min = lst[0];
  for (int i = 0; i < lst.length; i++) {
    if (lst[i] < min) {
      min = lst[i];
    }
  }
  return min;
}

public double abs(double n) {
  if (n <= 0) {
    return -n;
  } else {
    return n;
  }
}

public double cot(double n) {
  return 1 / tan(radians((float)n));
}

public double sin(double n) {
  return sin(radians((float)n));
}
public double cos(double n) {
  return cos(radians((float)n));
}
public double tan(double n) {
  return tan(radians((float)n));
}

public String myRound(int decimals, double n) {
  boolean negative = false;
  if (n < 0) {
    negative = true;
    n *= -1;
  } else if (n == 0) {
    return "0";
  }
  for (int i = 0; i < decimals; i++) {
    n *= 10;
  }
  n = round((float)n);
  if (decimals == 0) {
    if (negative) {
      return str((int) (float) - n);
    } else {
      return str((int) (float) n);
    }
  }
  for (int i = 0; i < decimals; i++) {
    n /= 10;
  }
  if (negative) {
    return str((float) -n);
  } else {
    return str((float) n);
  }
}
class Button {
  String name = "";
  float wide = 100;
  float high = 100;
  float borderRadius = 0;
  float x = 0;
  float y = 0;
  boolean state = false;
  int inActive = color(23, 20, 184);
  int active = color(86, 196, 227);
  int hover = color(30, 184, 200);
  int labelColor = 255;
  Button(String nameIn, float widthIn, float heightIn, float borderIn, float xIn, float yIn) {
    name = nameIn;
    wide = widthIn;
    high = heightIn;
    borderRadius = borderIn;
    x = xIn;
    y = yIn;
  }

  public boolean hover() {
    if (mouseX >= x && mouseX <= x + wide && mouseY >= y && mouseY <= high + y) {
      return true;
    } else {
      return false;
    }
  }
  public void update() {
    textSize(16);
    textAlign(CENTER, CENTER);
    noStroke();
    if (state) {
      fill(active);
      rect(x, y, wide, high, borderRadius);
    } else if (!state && this.hover()) {
      fill(hover);
      rect(x, y, wide, high, borderRadius);
    } else {
      fill(inActive);
      rect(x, y, wide, high, borderRadius);
    }
    fill(labelColor);
    textAlign(CENTER, CENTER);
    text(name, x + wide/2 , y + high / 2 - 3);
  }
}
//it aint easy being superior
class ImageButton {
  String name = "";
  float wide = 100;
  float high = 100;
  float borderRadius = 0;
  float x = 0;
  float y = 0;
  boolean state = false;
  int inActive = color(23, 20, 184);
  int active = color(86, 196, 227);
  int hover = color(30, 184, 200);
  int labelColor = 0;
  PImage background;
  
  ImageButton(String nameIn, float widthIn, float heightIn, float borderIn, float xIn, float yIn, String img) {
    name = nameIn;
    wide = widthIn;
    high = heightIn;
    borderRadius = borderIn;
    x = xIn;
    y = yIn;
    background = loadImage(img);
    background.resize(200, 0);
  }
  public void setRadius(float r) {
    borderRadius = r;
  }
  public void setLabelColor(int labelColorIn) {
    labelColor = labelColorIn;
  }
  public void setLabel(String nameIn) {
    name = nameIn;
  }
  public void setInActiveColor(int inActiveIn) {
    inActive = inActiveIn;
  }
  public void setActiveColor(int activeIn) {
    active = activeIn;
  }
  public void setHoverColor(int hoverIn) {
    hover = hoverIn;
  }
  public void setSize(float widthIn, float heightIn) {
    wide = widthIn;
    high = heightIn;
  }
  public void setPosition(float xIn, float yIn) {
    x = xIn;
    y = yIn;
  }
  public boolean hover() {
    if (mouseX >= x && mouseX <= x + wide && mouseY >= y && mouseY <= high + y) {
      return true;
    } else {
      return false;
    }
  }
  public void update() {
    textSize(18);
    noStroke();
    fill(255);
    if (state) {
      rect(x, y, wide, high, borderRadius);
      image(background, x, y, background.width, background.height);
    } else if (!state && this.hover()) {
      rect(x, y, wide, high, borderRadius);
      image(background, x - background.width * 0.05f, y - background.height * 0.05f, background.width * 1.1f, background.height * 1.1f);
    } else {
      rect(x, y, wide, high, borderRadius);
      image(background, x, y, background.width, background.height);
    }
    fill(labelColor);
    textAlign(CENTER, TOP);
    text(name, x + wide/2 , y + high);
  }
}
//it aint easy being superior
class Input {
  TextField [] inputs;
  int currentField = 0;
  String [] inputStrings;

  Input(int numInputs, String [] inputPrompts) {
    inputStrings = inputPrompts;
    inputs = new TextField[numInputs];
    for (int i = 0; i < inputs.length; i++) {
      inputs[i] = new TextField(70, 10, 80 + 50 * i);
    }
    if (numInputs > 0) {
      inputs[0].state = true;
    }
  }

  public void update() {

    // showing input page
    for (int i = 0; i < inputs.length; i++) {
      inputs[i].update();
      fill(0);
      textSize(16);
      text(inputStrings[i], 10, 60 + 50 * i);
    }
    //updating input page buttons
    creditsButton.update();
    submit.update();
    back.update();

    //updating all text fields
    for (int i = 0; i < inputs.length; i++) {
      inputs[i].update();
    }
  }

  public void keyPressed() {

    //if the tab or down arrow is pressed activate the next texfield
    if (key == TAB || keyCode == DOWN) {

      //deactivate current textfield
      inputs[currentField].state = false;

      //try going to the next element and activating it
      try {
        inputs[currentField + 1].state = true;
        currentField++;
      }

      //if this raised indexoutofboundserror activate the first textfield 
      catch(Exception e) {
        inputs[0].state = true;
        currentField = 0;
      }
    } 

    //if the up arrow is pressed select the previous textfield
    else if (keyCode == UP) {

      //deactivate current textfield
      inputs[currentField].state = false;

      //if first textfield is active, activate last textfield
      if (currentField == 0) {
        inputs[inputs.length - 1].state = true;
        currentField = inputs.length - 1;
      } 

      //otherwise activate previous textfield
      else {
        inputs[currentField - 1].state = true;
        currentField--;
      }
    }

    //if another key is pressed, pass the event down to the textfields
    else {
      for (int i = 0; i < inputs.length; i++) {
        inputs[i].keyPressed();
      }
    }
  }

  public void mouseClicked() {

    //going back to home page, resetting all question state to false
    if (back.hover()) {
      superReset();
      home = true;
    }

    //going to credits page
    else if (creditsButton.hover()) {
      superReset();
      credits = true;
    }

    //otherwise pass event down to textfields
    else {
      for (int i = 0; i < inputs.length; i++) {
        inputs[i].mouseClicked();
      }
    }
  }

  public void reset() {
    try {
      inputs[0].state = true;
      inputs[0].clear();
    }
    catch(Exception e) {
    }
    for (int i = 1; i < inputs.length; i++) {
      inputs[i].state = false;
      inputs[i].clear();
      currentField = 0;
    }
  }
}
class Output {
  
  String message = "";

  Output() {
  }

  public void update() {

    //showing output page
    textSize(16);
    text(message, 10, 50);

    //showing output page buttons
    back.update();
    creditsButton.update();
    if (!questions[0].active) {
      solutions.update();
    }
  }

  public void mouseClicked() {

    //going back to home page, resetting all question state to false
    if (back.hover()) {
      superReset();
      home = true;
    }

    //going to credits page
    else if (creditsButton.hover()) {
      superReset();
      credits = true;
    } 
    
    //going to solutions page
    else if (solutions.hover() && !questions[0].active) {
      output = false;
      showSteps = true;
      showSolutions();
      surface.setSize(1000, 1000);
    }
  }
}
class Question {
  boolean active = false;
  boolean validInput = false;
  int questionNum;
  String message = "";
  double [] data;
  PImage pic;

  ImageButton mainButton;
  Input myInput;
  Output myOutput;
  Steps mySteps;


  Question(int numInputs, int qNum, String [] inputPrompts, int x, int y, String img, String solution) {
    questionNum = qNum;
    data = new double[numInputs];
    mainButton = new ImageButton("Question " + questionNum, 200, 100, 10, x, y, img);
    myInput = new Input(numInputs, inputPrompts);
    myOutput = new Output();
    mySteps = new Steps(solution);
    pic = loadImage(img);
    pic.resize(300, 0);
  }

  public void update() {

    //if the question is selected
    if (active) {


      if (!showSteps) {
        showQNum();
        pic.resize(300, 0);
        image(pic, 490, 50);
      }

      if (input) {
        myInput.update();
      } else if (output) {
        myOutput.update();
      } else if (showSteps) {
        fill(0);
        textSize(30);
        textAlign(LEFT, TOP);
        text("Question " + questionNum + " -", 10, 10);
        mySteps.update();
      }
    }
  }

  public void mouseClicked() {

    //if this question is selected
    if (active) {

      if (input) {
        if (submit.hover()) {
          solve();
        } else {
          myInput.mouseClicked();
        }
      } else if (output) {
        myOutput.mouseClicked();
      } else if (showSteps) {
        mySteps.mouseClicked();
      }
    }
  }

  public void keyPressed() {

    //if the question is selected
    if (active) {

      //if the ENTER or RETURN key is pressed, solve the problem
      if (key == ENTER || key == RETURN) {
        if (active && input) {
          solve();
        } else if ( active && output ) {
          output = false;
          showSteps = true;
          showSolutions();
        }
      }

      //otherwise pass the event down to the input
      else {
        myInput.keyPressed();
      }
    }
  }

  public void getInput() {
    validInput = true;
    for (int i = 0; i < myInput.inputs.length; i++) {
      try {
        data[i] = Float.parseFloat(myInput.inputs[i].value);
      }
      catch(Exception e) {
        validInput = false;
        JOptionPane.showMessageDialog(null, "Please enter only numbers. Units are not necessary.", "INVALID INPUT!", JOptionPane.ERROR_MESSAGE);
        break;
      }
    }
  }

  public void solve() {
    switch(questionNum) {

    case 1:
      getInput();
      if (validInput) {
        message = question1(data);
        input = false;
        output = true;
      }
      break;

    case 2:
      getInput();
      if (validInput) {
        message = question2(data);
        input = false;
        output = true;
      }
      break;

    case 3:
      getInput();
      if (validInput) {
        message = question3(data);
        input = false;
        output = true;
      }
      break;

    case 4:
      getInput();
      if (validInput) {
        message = question4(data);
        input = false;
        output = true;
      }
      break;

    case 5:
      getInput();
      if (validInput) {
        message = question5(data);
        input = false;
        output = true;
      }
      break;
    }
    myOutput.message = message;
  }

  public void showQNum() {
    fill(0);
    textSize(30);
    textAlign(LEFT, TOP);
    text("Question " + questionNum + ":", 10, 10);
  }

  public void reset() {
    active = false;
    myInput.reset();
    data = new double[myInput.inputs.length];
  }
}
class Settings {
  Slider MaxY;
  Button cancel;
  Button apply;

  Settings() {
    MaxY = new Slider(50, 130, 200, 20, 700, 1100);
    cancel = new Button("Cancel", 50, 25, 5, 50, 425);
    apply = new Button("Apply", 50, 25, 5, 375, 425);
  }

  public void update() {
    textSize(30);
    fill(0);
    textAlign(LEFT, TOP);
    text("Settings:", 10, 10);

    textSize(16);
    text("Adjust the slider to the desired maximum window height.\nThis will only affect the solutions pages, the default value is 1000.", 10, 50);
    MaxY.update();
    back.update();
    apply.update();
    cancel.update();
    surface.setSize(800, MaxY.currentVal - 20);
    back.y = MaxY.currentVal - 75;
    cancel.y = MaxY.currentVal - 75;
    apply.y = MaxY.currentVal - 75;
  }

  public void mousePressed() {
    MaxY.mousePressed();
    if (back.hover() || cancel.hover()) {
      superReset();
      home = true;
    } 
    //do not apply settings
    else if (cancel.hover()) {
      superReset();
      home = true;
    } 
    //apply settings
    else if (apply.hover()) {
      maxY = MaxY.currentVal;
      superReset();
      home = true;
      for (int i = 1; i < questions.length; i++) {
        questions[i].mySteps.solution.resize(0, (maxY - 60));
      }
    }
  }

  public void mouseDragged() {
    MaxY.mouseDragged();
  }
}
class Slider {
  float x;
  float y;
  float w;
  float h;
  float min;
  float max;
  int inActive = color(23, 20, 184);
  int active = color(30, 184, 200);
  int backgroundColor = color (255);
  int labelColor = color(0);
  float slideWidth = 15;
  float radius = 10;
  float slideX;
  float offSet;
  boolean activeBool = false;
  int currentVal;

  Slider(float xIn, float yIn, float widthIn, float heightIn, float minIn, float maxIn) {
    x = xIn;
    y = yIn;
    w = widthIn;
    h = heightIn;
    min = minIn;
    max = maxIn;
    slideX = xIn;
    currentVal = (int) min;
  }

  public boolean hover() {
    if (mouseX >= slideX && mouseX <= slideX + slideWidth && mouseY >= y - 10 && mouseY < y + h + 10) {
      return true;
    } else {
      return false;
    }
  }

  public void mouseDragged() {
    if (activeBool) {
      if (mouseX - offSet < x + w) {
        slideX = mouseX - offSet;
      }
    }
  }
  
  public void mousePressed() {
    if(hover()) {
      this.activeBool = true;
      offSet = mouseX - slideX;
    }
  }

  public void update() {
    noStroke();
    fill(inActive);
    rect(x, y, w, h, radius);

    //setting left bound
    if (slideX < x) {
      slideX = x;
    }
    //setting right bound
    if (slideX + slideWidth > x + w) {
      slideX = x + w - slideWidth;
    }

    //if mouseover slider
    if ((hover())) {
      fill(active);
      rect(slideX, y - 10, slideWidth, h + 20, radius);
    } else {
      fill(inActive);
      rect(slideX, y - 10, slideWidth, h + 20, radius);
    }

    //setting current min and max based on position of slider
    currentVal = (int) map(slideX, x, x + w - slideWidth, min, max);

    //printing value
    fill(labelColor);
    textAlign(LEFT, TOP);
    textSize(16);
    text(currentVal, x, y + h + 10);
  }
}
//it aint easy being superior
class Steps {
  PImage solution;
  Steps(String steps) {
    solution = loadImage(steps);
    solution.resize(0, maxY - 60);
    if(solution.width > 1800) {
      solution.resize(1800, 0);
    }
  }

  public void update() {
    textAlign(LEFT, TOP);
    textSize(30);
    fill(0);
    text("Example Solution:", 200, 10);
    image(solution, 10, 50);

    back.update();
    creditsButton.update();
  }

  public void mouseClicked() {
    if (back.hover()) {
      superReset();
      home = true;
    } else if (creditsButton.hover()) {
      superReset();
      credits = true;
    }
  }
}
class TextField {
  float w, x, y, h = 20;
  int background = color(214, 210, 210);
  boolean state = false;
  String value = "";

  TextField(float wIn, float xIn, float yIn) {
    w = wIn;
    x = xIn;
    y = yIn;
  }

  public boolean hover() {
    if (mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= h + y) {
      return true;
    } else {
      return false;
    }
  }

  public void mouseClicked() {
    //if the textfield is clicked on it will become active
    if (hover()) {
      state = true;
    }
    //if anywhere else if clicked it will become inactive
    else {
      state = false;
    }
  }

  public void keyPressed() {

    //if the textfield is active
    if (state) {

      //if the user presses delete or backspace, delete the last character in the textfield
      if (key == BACKSPACE || key == DELETE) {
        if (value.length() > 0) {
          value = value.substring(0, value.length() - 1);
        }
      } else {
        value += key;
      }
    }
  }

  public void clear() {
    value = "";
  }

  public void update() {
    textAlign(LEFT, TOP);
    fill(background);
    textSize(15);
    if (state) {
      stroke(0);
      rect(x, y, w, h, 5);
      fill(0);
      text(value, x + 5, y + 1.5f);
      //covering overflow
      fill(255);
      noStroke();
      rect(x + w + 1, y, 400, h);
    } else {
      fill(background);
      noStroke();
      rect(x, y, w, h, 5);
      fill(0);
      text(value, x + 5, y + 1.5f);
      //covering overflow
      fill(255);
      noStroke();
      rect(x + w + 1, y, 400, h);
    }
  }
}
  public void settings() {  size(800, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Assignment11" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
